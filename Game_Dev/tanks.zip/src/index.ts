import Game from './pixi/Game'

new Game()